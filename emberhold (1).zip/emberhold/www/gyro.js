// Гироскоп: devicemotion + автокалибровка осей отдельно для angle 90 и 270.
const Gyro=(()=>{
const DEF={mode:'ads',sensHip:1,sensAds:.7,mx:1,my:1,invX:false,invY:false,dead:.4,smooth:.2,precise:false,vehicle:false,rad:false,profile:{},bias:[0,0,0]};
let cfg=Object.assign({},DEF,JSON.parse(localStorage.getItem('emb_gyro')||'{}'));
const G={cfg,enabled:false,supported:typeof DeviceMotionEvent!=='undefined',paused:false,hold:false,running:false,
 accYaw:0,accPitch:0,last:0,fy:0,fp:0,rawRate:[0,0,0],grav:[0,0,9.8],dotYaw:0,hasData:false,sink:null,peak:0,
 save(){localStorage.setItem('emb_gyro',JSON.stringify(cfg))},
 angle(){let a=(screen.orientation&&screen.orientation.angle!=null)?screen.orientation.angle:(window.orientation||0);a=((a%360)+360)%360;return a===270||a===90?a:90},
 prof(){const a=this.angle();return cfg.profile[a]||(cfg.profile[a]={yi:1,ys:1,pi:2,ps:1,ds:1})},
 async requestPermission(){
  if(typeof DeviceMotionEvent!=='undefined'&&typeof DeviceMotionEvent.requestPermission==='function'){
   try{return(await DeviceMotionEvent.requestPermission())==='granted'}catch(e){return false}}
  return this.supported},
 start(){if(this.running||!this.supported)return;this.running=true;this.last=0;addEventListener('devicemotion',this.onMotion)},
 stop(){if(!this.running)return;this.running=false;removeEventListener('devicemotion',this.onMotion);this.accYaw=this.accPitch=0},
 onMotion(e){
  const rr=e.rotationRate;if(!rr||rr.alpha==null&&rr.beta==null)return;
  const now=performance.now();const dt=G.last?Math.min((now-G.last)/1000,.1):0;G.last=now;G.hasData=true;
  let k=cfg.rad?57.2958:1;
  const w=[(rr.beta||0)*k,(rr.gamma||0)*k,(rr.alpha||0)*k]; // x,y,z
  const ag=e.accelerationIncludingGravity;if(ag&&ag.x!=null){G.grav=[ag.x,ag.y,ag.z]}
  G.rawRate=w;G.peak=Math.max(G.peak*.995,Math.abs(w[0]),Math.abs(w[1]),Math.abs(w[2]));
  const g=G.grav,gl=Math.hypot(g[0],g[1],g[2])||1;G.dotYaw=(w[0]*g[0]+w[1]*g[1]+w[2]*g[2])/gl;
  if(!dt||!G.enabled)return;
  const p=G.prof(),b=cfg.bias;
  let yr=cfg.precise?G.dotYaw*p.ds:(w[p.yi]-b[p.yi])*p.ys, pr=(w[p.pi]-b[p.pi])*p.ps;
  yr=G.dz(yr);pr=G.dz(pr);
  const s=1-cfg.smooth;G.fy+=(yr-G.fy)*s;G.fp+=(pr-G.fp)*s;
  G.accYaw+=G.fy*dt;G.accPitch+=G.fp*dt;
  if(G.sink)G.sink(G.fy,G.fp,w)},
 dz(v){const a=Math.abs(v),d=cfg.dead;if(a<d)return v*(a/d)*(a/d);return v},
 // Вызывать раз в кадр. Возвращает радианы: yaw (вправо +), pitch (вверх +)
 consume(isAds,zoom,firing,inVehicle){
  const y=this.accYaw,p=this.accPitch;this.accYaw=this.accPitch=0;
  if(!this.enabled||this.paused||cfg.mode==='off')return{yaw:0,pitch:0};
  const m=cfg.mode;
  if(inVehicle&&!cfg.vehicle)return{yaw:0,pitch:0};
  if(m==='ads'&&!isAds)return{yaw:0,pitch:0};
  if(m==='hold'&&!this.hold)return{yaw:0,pitch:0};
  if(m==='adsfire'&&!(isAds&&firing))return{yaw:0,pitch:0};
  const sens=(isAds?cfg.sensAds/Math.max(1,zoom||1):cfg.sensHip)*.0175;
  return{yaw:y*sens*cfg.mx*(cfg.invX?-1:1),pitch:p*sens*cfg.my*(cfg.invY?-1:1)}},
 // Калибровка: onStep(text), возвращает Promise<boolean>
 async calibrate(onStep){
  const wait=ms=>new Promise(r=>setTimeout(r,ms));
  const grab=async(ms)=>{const s=[0,0,0],a=[0,0,0],sd=0,t0=performance.now();let dy=0,n=0,pk=0;
   const h=e=>{const rr=e.rotationRate;if(!rr)return;const w=[rr.beta||0,rr.gamma||0,rr.alpha||0];const ag=e.accelerationIncludingGravity||{x:0,y:0,z:9.8};
    const gl=Math.hypot(ag.x,ag.y,ag.z)||1;dy+=(w[0]*ag.x+w[1]*ag.y+w[2]*ag.z)/gl;
    for(let i=0;i<3;i++){s[i]+=w[i];a[i]+=Math.abs(w[i]);pk=Math.max(pk,Math.abs(w[i]))}n++};
   addEventListener('devicemotion',h);await wait(ms);removeEventListener('devicemotion',h);return{s,a,n,dy,pk}};
  if(!this.supported)return false;
  const ok=await this.requestPermission();if(!ok)return false;
  const p=this.prof();
  onStep('Шаг 1/3: положи телефон спокойно и не двигай (1 сек)');await wait(800);
  const r0=await grab(1000);if(!r0.n){onStep('Датчик не отвечает');return false}
  cfg.bias=r0.s.map(v=>v/r0.n);
  onStep('Шаг 2/3: ПОВЕРНИ телефон вправо, как голову (1.5 сек)…');await wait(600);
  const r1=await grab(1500);
  if(r1.pk<10&&r1.pk>0){cfg.rad=true;cfg.bias=cfg.bias.map(v=>v*57.2958);for(let i=0;i<3;i++){r1.s[i]*=57.2958;r1.a[i]*=57.2958}r1.dy*=57.2958}
  let yi=0;for(let i=1;i<3;i++)if(Math.abs(r1.s[i])>Math.abs(r1.s[yi]))yi=i;
  p.yi=yi;p.ys=Math.sign(r1.s[yi]-cfg.bias[yi]*r1.n)||1;p.ds=Math.sign(r1.dy)||1;
  onStep('Шаг 3/3: НАКЛОНИ верх телефона вверх (1.5 сек)…');await wait(600);
  const r2=await grab(1500);if(cfg.rad){for(let i=0;i<3;i++)r2.s[i]*=57.2958}
  let pi=-1;for(let i=0;i<3;i++){if(i===yi)continue;if(pi<0||Math.abs(r2.s[i])>Math.abs(r2.s[pi]))pi=i}
  p.pi=pi;p.ps=Math.sign(r2.s[pi]-cfg.bias[pi]*r2.n)||1;
  this.save();onStep('Готово! Профиль сохранён для этой стороны экрана.');return true},
 center(){ // пересчёт bias за 1 сек покоя
  const s=[0,0,0];let n=0;const h=e=>{const r=e.rotationRate;if(!r)return;const k=cfg.rad?57.2958:1;s[0]+=(r.beta||0)*k;s[1]+=(r.gamma||0)*k;s[2]+=(r.alpha||0)*k;n++};
  addEventListener('devicemotion',h);setTimeout(()=>{removeEventListener('devicemotion',h);if(n){cfg.bias=s.map(v=>v/n);G.save()}},1000)},
 reset(){Object.assign(cfg,JSON.parse(JSON.stringify(DEF)));this.save()}};
document.addEventListener('visibilitychange',()=>{if(document.hidden)G.stop();else if(G.enabled)G.start()});
return G})();
