// Звук: SFX через WebAudio (декодируются), музыка — потоком через <audio>.
const Snd=(()=>{
const VAR={step:4,hit_wood:2,hit_stone:2,hurt:2},SFX=['step_1','step_2','step_3','step_4','hit_wood_1','hit_wood_2','hit_stone_1','hit_stone_2','hit_flesh','swing','shot_pistol','shot_rifle','bow','hurt_1','hurt_2','pickup','click','craft_done','reload','door','explosion','growl','bite','splash','ui_open'],LOOPS=['wind','waves','fire','night'];
let ctx=null,sfxG,buf={},loops={},mus={},cur='',vol={sfx:1,music:.5},amb={wind:0,waves:0,fire:0,night:0},last={};
async function ld(n,dst){try{const r=await fetch('assets/sfx/'+n+'.wav');const b=await ctx.decodeAudioData(await r.arrayBuffer());dst[n]=b}catch(e){}}
const api={vol,
 init(){if(ctx){if(ctx.state==='suspended')ctx.resume();return}
  const AC=window.AudioContext||window.webkitAudioContext;if(!AC)return;ctx=new AC();sfxG=ctx.createGain();sfxG.connect(ctx.destination);
  SFX.forEach(n=>ld(n,buf));
  LOOPS.forEach(async n=>{const t={};await ld('loop_'+n,t);const b=t['loop_'+n];if(!b)return;const s=ctx.createBufferSource(),g=ctx.createGain();s.buffer=b;s.loop=true;g.gain.value=0;s.connect(g);g.connect(sfxG);s.start();loops[n]=g});
  ['lobby','day','night'].forEach(n=>{const a=new Audio('assets/music/'+n+'.wav');a.loop=true;a.preload='auto';a.volume=0;mus[n]=a})},
 play(n,v=1,rate=1,minGap=0){if(!ctx||!sfxG)return;const now=performance.now();if(minGap&&last[n]&&now-last[n]<minGap)return;last[n]=now;
  const k=VAR[n]?n+'_'+(1+Math.floor(Math.random()*VAR[n])):n,b=buf[k];if(!b)return;
  const s=ctx.createBufferSource(),g=ctx.createGain();s.buffer=b;s.playbackRate.value=rate*(.95+Math.random()*.1);g.gain.value=Math.min(1.5,v)*vol.sfx;s.connect(g);g.connect(sfxG);s.start()},
 at(n,x,z,px,pz,v=1){const d=Math.hypot(x-px,z-pz);const g=v*Math.max(0,1-d/90);if(g>.02)this.play(n,g)},
 music(n){if(n===cur)return;cur=n;Object.keys(mus).forEach(k=>{if(k===n){mus[k].play().catch(()=>{})}})},
 ambient(o){Object.assign(amb,o)},
 tick(dt){if(!ctx)return;Object.keys(loops).forEach(k=>{const g=loops[k].gain;g.value+=((amb[k]||0)*vol.sfx-g.value)*Math.min(1,dt*2)});
  Object.keys(mus).forEach(k=>{const a=mus[k],t=k===cur?vol.music:0;a.volume=Math.max(0,Math.min(1,a.volume+(t-a.volume)*Math.min(1,dt*.8)));if(k!==cur&&a.volume<.01&&!a.paused)a.pause()})}};
return api})();
