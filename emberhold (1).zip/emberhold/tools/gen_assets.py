# Генерирует реальные ассеты EMBERHOLD (звуки, музыка, текстуры, фон меню). Запускается при `npm install`.
import sys,os,subprocess,math,wave
try:
    import numpy as np
    from PIL import Image
except ImportError:
    for extra in (['--break-system-packages'],[]):
        try:
            subprocess.check_call([sys.executable,'-m','pip','install','--quiet']+extra+['numpy','pillow']);break
        except subprocess.CalledProcessError:
            continue
    import numpy as np
    from PIL import Image
ROOT=os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','www','assets'))
for d in('sfx','music','tex','ui'):os.makedirs(os.path.join(ROOT,d),exist_ok=True)
SR=44100;rng=np.random.default_rng(7)
def save(p,x):
    x=np.clip(x/max(1e-9,np.abs(x).max())*.9,-1,1)
    with wave.open(os.path.join(ROOT,p),'wb') as w:
        w.setnchannels(1);w.setsampwidth(2);w.setframerate(SR);w.writeframes((x*32767).astype('<i2').tobytes())
T=lambda d:np.arange(int(d*SR))/SR
def lp(x,k):
    if k<=1:return x
    c=np.cumsum(np.insert(x,0,0));y=(c[k:]-c[:-k])/k
    return np.concatenate([np.full(k-1,y[0]),y])
hp=lambda x,k:x-lp(x,k)
nz=lambda n:rng.standard_normal(n)
def burst(d,dec,k):tt=T(d);return lp(nz(len(tt)),k)*np.exp(-tt*dec)
def tone(f,d,dec,sw=0):tt=T(d);return np.sin(2*np.pi*np.cumsum(f*(1+sw*tt))/SR)*np.exp(-tt*dec)
def mix(*a):
    n=max(len(x) for _,x in a);o=np.zeros(n)
    for off,x in a:s=int(off*SR);o[s:s+len(x)]+=x[:max(0,n-s)]
    return o
# ---- SFX
for i,k in enumerate([18,30,24,40],1):save(f'sfx/step_{i}.wav',mix((0,burst(.14,28,k)*.8),(0,tone(70+i*8,.1,40)*.4)))
for i,f in enumerate([160,200],1):save(f'sfx/hit_wood_{i}.wav',mix((0,tone(f,.18,22)*.7),(0,tone(f*2,.1,30)*.3),(0,burst(.08,60,6))))
for i,f in enumerate([900,1100],1):save(f'sfx/hit_stone_{i}.wav',mix((0,tone(f,.2,18)*.4),(0,tone(f*2,.1,40)*.2),(0,burst(.07,70,3))))
save('sfx/hit_flesh.wav',mix((0,tone(80,.2,18)),(0,burst(.1,40,12)*.8)))
tt=T(.25);save('sfx/swing.wav',(lp(nz(len(tt)),6)-lp(nz(len(tt)),60))*np.sin(np.pi*tt/.25))
save('sfx/shot_pistol.wav',mix((0,burst(.35,9,5)),(0,tone(55,.4,9,-2)*1.2),(0,burst(.03,120,1)*1.5)))
save('sfx/shot_rifle.wav',mix((0,burst(.28,12,4)),(0,tone(75,.25,14,-2)),(0,burst(.03,150,1)*1.5)))
save('sfx/bow.wav',mix((0,tone(200,.5,10,-.6)*.6),(0,burst(.15,25,10)*.4)))
for i in(1,2):save(f'sfx/hurt_{i}.wav',mix((0,tone(300+i*40,.3,6,-1.5)),(0,burst(.2,12,20)*.6)))
save('sfx/pickup.wav',mix((0,tone(660,.1,18)),(.06,tone(990,.12,18))))
save('sfx/click.wav',mix((0,burst(.03,150,2)),(0,tone(1200,.03,90)*.3)))
save('sfx/craft_done.wav',mix((0,tone(523,.2,12)),(.1,tone(659,.2,12)),(.2,tone(784,.3,9))))
save('sfx/reload.wav',mix((0,burst(.04,120,2)+tone(900,.04,80)*.3),(.35,burst(.05,100,2)+tone(700,.05,80)*.3),(.6,burst(.06,90,3))))
tt=T(.5);save('sfx/door.wav',lp(sum(((2*((f*tt+.2*np.sin(9*tt))%1)-1)) for f in(110,165,220)),12)*np.sin(np.pi*tt/.5))
save('sfx/explosion.wav',mix((0,burst(1.8,2.2,50)*1.2),(0,tone(45,1.5,2.5)*1.5),(0,burst(.1,30,2)*2)))
tt=T(.9);g=lp(sum(2*((f*tt)%1)-1 for f in(70,75,142)),6)*(.6+.4*np.sin(2*np.pi*18*tt))+lp(nz(len(tt)),10)*.5;save('sfx/growl.wav',g*np.sin(np.pi*tt/.9))
save('sfx/bite.wav',mix((0,burst(.15,30,8)),(0,tone(120,.15,25))))
save('sfx/splash.wav',burst(.5,7,15))
save('sfx/ui_open.wav',mix((0,tone(440,.15,14)),(.05,tone(660,.2,12))))
def loop(x,xf=2.0):
    n=int(xf*SR);o=x[:-n].copy();a=np.linspace(0,1,n);o[:n]=o[:n]*a+x[-n:]*(1-a);return o
L=32;tt=T(L)
save('sfx/loop_wind.wav',loop((lp(nz(len(tt)),220)*(.7+.3*np.sin(2*np.pi*.07*tt))+lp(nz(len(tt)),40)*.25*(.5+.5*np.sin(2*np.pi*.13*tt+1)))))
save('sfx/loop_waves.wav',loop(lp(nz(len(tt)),70)*(.55+.45*np.sin(2*np.pi*.11*tt))+hp(lp(nz(len(tt)),6),40)*.08*(.5+.5*np.sin(2*np.pi*.11*tt+.6))))
f=lp(nz(len(tt)),90)*.1;cr=np.zeros(len(tt));pos=rng.integers(0,len(tt)-800,int(12*L));tp=burst(.02,200,2)[:800]
for p in pos:cr[p:p+len(tp)]+=tp*rng.uniform(.3,1.2)
save('sfx/loop_fire.wav',loop(f+cr*1.5))
c=np.zeros(len(tt))
for i,fr in enumerate((4100,4300,4550)):
    gate=lp(((np.sin(2*np.pi*(16+i*1.7)*tt)>0)*(np.sin(2*np.pi*(1.1+i*.23)*tt+i)>-.3)).astype(float),60);c+=np.sin(2*np.pi*fr*tt)*gate*.3
save('sfx/loop_night.wav',loop(c+lp(nz(len(tt)),300)*.05))
# ---- МУЗЫКА (3 трека по ~2 мин)
A=110.0;fr=lambda s:A*2**(s/12)
def track(name,bpm,prog,dur,drums,arp,seed):
    r=np.random.default_rng(seed);beat=60/bpm;bar=int(beat*4*SR);sec=[]
    for root,kind in prog:
        tt=np.arange(bar)/SR;ch=[root,root+(3 if kind=='m' else 4),root+7,root+12]
        pad=sum(lp(sum(2*(((fr(n+12)*m)*tt)%1)-1 for m in(.997,1,1.004)),22) for n in ch)*.05
        pad*=np.minimum(1,tt/.6)*np.minimum(1,(tt[-1]-tt)/.5+.3)
        b=np.zeros(bar)
        for q in(0,2):
            s=int(q*beat*SR);bt=T(beat*2)[:bar-s];b[s:s+len(bt)]+=np.sin(2*np.pi*fr(root-12)*bt)*np.exp(-bt*1.6)*.35
        o=pad+b
        if arp:
            for q in range(8):
                s=int(q*beat/2*SR);at=T(beat)[:bar-s];n=ch[[0,2,1,3,2,1,3,1][q]]+12
                o[s:s+len(at)]+=(np.sin(2*np.pi*fr(n)*at)+.3*np.sin(4*np.pi*fr(n)*at))*np.exp(-at*5)*.1
        if drums:
            for q in range(4):
                s=int(q*beat*SR);kt=T(.25)[:bar-s];o[s:s+len(kt)]+=tone(62,.25,13,-2)[:len(kt)]*.5
                s2=int((q+.5)*beat*SR);h=burst(.05,90,1)[:bar-s2];o[s2:s2+len(h)]+=hp(h,3)*.08
        sec.append(o)
    s=np.concatenate(sec);n=int(dur*SR);x=np.tile(s,n//len(s)+1)[:n]
    x*=np.minimum(1,np.arange(n)/(4*SR))*np.minimum(1,(n-np.arange(n))/(6*SR));save(f'music/{name}.wav',x)
track('lobby',72,[(0,'m'),(-4,'M'),(3,'M'),(-2,'M')],130,False,True,1)
track('day',92,[(0,'m'),(-2,'M'),(-4,'M'),(-5,'M')],130,True,True,2)
track('night',58,[(0,'m'),(5,'m'),(0,'m'),(7,'M')],130,False,False,3)
# ---- ТЕКСТУРЫ 1024
N=1024;yy,xx=np.mgrid[0:N,0:N]/N;yy=yy.astype(np.float32);xx=xx.astype(np.float32)
def pn(terms,seed,mf=16,pw=1.0,ax=None):
    r=np.random.default_rng(seed);o=np.zeros((N,N),np.float32)
    for _ in range(terms):
        fx,fy=r.integers(-mf,mf+1,2)
        if ax=='x':fy=r.integers(-1,2)
        if fx==0 and fy==0:continue
        o+=np.sin(2*np.pi*(fx*xx+fy*yy)+r.uniform(0,6.28))/(1+math.hypot(fx,fy))**pw
    return o/np.abs(o).max()
def img(rgb,name):
    a=np.stack([np.clip(c,0,1) for c in rgb],-1);Image.fromarray((a*255).astype('uint8')).save(os.path.join(ROOT,'tex',name+'.png'),optimize=False)
gr=lambda s:rng.normal(0,s,(N,N)).astype(np.float32)
g=.82+.1*pn(60,1)+.05*pn(60,2,64)+gr(.03);img([g,g,g],'detail')
w=pn(60,3,48,.6,'x');b=.35+.12*w+.05*pn(40,4,6)+gr(.025);img([b*1.2,b*.85,b*.55],'bark')
pl=np.floor(yy*4);edge=(np.abs((yy*4)%1-.5)>.47)*1.0;shade=np.array([.9,1,.8,.95])[pl.astype(int)%4]
w=.5+.13*pn(70,5,40,.5,'x')+.04*pn(30,6,6)+gr(.02);img([w*1.05*shade*(1-.5*edge),w*.72*shade*(1-.5*edge),w*.42*shade*(1-.5*edge)],'wood')
ro=np.floor(yy*8);col=np.floor((xx*4+(ro%2)*.5)%4);bs=(np.random.default_rng(9).uniform(.7,1,(8,4)))[ro.astype(int)%8,col.astype(int)%4]
mort=((yy*8)%1<.06)|(((xx*4+(ro%2)*.5)%1)<.04);s=bs*(.55+.1*pn(50,7,40)+gr(.03));s=np.where(mort,.25,s);img([s*.95,s*.9,s*.85],'brick')
m=.5+.05*pn(60,8,60,.3,'x')+gr(.02);rv=np.zeros((N,N),np.float32)
for cx in(.125,.375,.625,.875):
    for cy in(.125,.375,.625,.875):rv+=(((xx-cx)**2+(yy-cy)**2)<.00025)*1.0
m=m+.25*rv-.0*pn(5,1);sc=np.abs(pn(8,10,80,0.1))>.985;m=np.where(sc,m+.2,m);img([m*.82,m*.88,m*1.0],'metal')
cr=np.abs(pn(40,11,10,.8));k=.55+.2*pn(60,12,30)+gr(.03);k=np.where(cr<.03,.2,k);img([k,k*.97,k*.92],'rock')
# ---- ФОН МЕНЮ 1920x1080
W,Hh=1920,1080;Y,X=np.mgrid[0:Hh,0:W].astype(np.float32);v=Y/Hh
sky=np.stack([.02+.18*v**2,.03+.14*v**1.5,.10+.28*v],-1)
gal=np.exp(-(((X-1500)/260)**2+((Y-260)/200)**2))*.25+np.exp(-(((X-1150)/380)**2+((Y-120)/90)**2))*.12
sky+=np.stack([gal*.9,gal*.75,gal*1.1],-1)
st=rng.random((Hh,W))>.9988;sky+=(st*rng.uniform(.4,1,(Hh,W)))[...,None]*(1-v[...,None]*.8)
def ridge(base,amp,seed,fq):
    r=np.random.default_rng(seed);x=np.arange(W);h=np.zeros(W)
    for i in range(1,7):h+=r.uniform(.5,1)/i*np.sin(x/W*np.pi*fq*i+r.uniform(0,6))
    return base+amp*h
for base,amp,seed,fq,c in((640,70,1,3,(.16,.20,.30)),(740,60,2,5,(.12,.15,.19)),(860,40,3,8,(.08,.09,.10))):
    hz=ridge(base,amp,seed,fq);mk=Y>hz[None,:];sky=np.where(mk[...,None],np.array(c)*(1-.2*np.sin(X[...,None]/90)*.2),sky)
fort=(((X>1300)&(X<1850)&(Y>700)&(Y<880))&((X%24)<20))|(((X>1500)&(X<1560)&(Y>560)&(Y<880)))|(((X>1360)&(X<1420)&(Y>610)&(Y<880)))
sky=np.where(fort[...,None],np.array([.05,.05,.06]),sky)
glow=np.exp(-(((X-1600)**2+(Y-700)**2)/90000))*.18;sky+=np.stack([glow*1.0,glow*.45,glow*.1],-1)
sky+=rng.normal(0,.006,sky.shape);Image.fromarray((np.clip(sky,0,1)*255).astype('uint8')).save(os.path.join(ROOT,'ui','bg_lobby.png'))
tot=sum(os.path.getsize(os.path.join(dp,f)) for dp,_,fs in os.walk(ROOT) for f in fs);print('assets MB:',round(tot/1048576,1))
