(()=>{'use strict';
const D=DATA,T=THREE,IT=D.items,$=i=>document.getElementById(i),clamp=(v,a,b)=>Math.max(a,Math.min(b,v)),rnd=(a,b)=>a+Math.random()*(b-a),lerp=(a,b,t)=>a+(b-a)*t;
const defS={sens:1,adsSens:.6,fov:75,gfx:1,invY:false,fps:false,vib:true,assist:50,adsHold:true};
const S=Object.assign({},defS,JSON.parse(localStorage.getItem('emb_set')||'{}'));const saveS=()=>localStorage.setItem('emb_set',JSON.stringify(S));
// ---------- шум и мир ----------
const SEED=D.world.seed,SZ=D.world.size;
function hash(x,y){const n=Math.sin(x*127.1+y*311.7+SEED)*43758.5453;return n-Math.floor(n)}
function vn(x,y){const xi=Math.floor(x),yi=Math.floor(y),xf=x-xi,yf=y-yi,u=xf*xf*(3-2*xf),v=yf*yf*(3-2*yf);return hash(xi,yi)*(1-u)*(1-v)+hash(xi+1,yi)*u*(1-v)+hash(xi,yi+1)*(1-u)*v+hash(xi+1,yi+1)*u*v}
function H(x,z){const d=Math.hypot(x,z)/(SZ/2);const n=vn(x/70,z/70)*16+vn(x/25,z/25)*4+vn(x/9,z/9);return(n-10.5)+14*(1-Math.pow(d,1.5))}
const hubD=(x,z)=>Math.hypot(x-D.hub.x,z-D.hub.z);
function biome(z){return z<-120?'arctic':z>130?'desert':'temperate'}
// ---------- three ----------
const cv=$('c'),R=new T.WebGLRenderer({canvas:cv,antialias:false,powerPreference:'high-performance'});
const scene=new T.Scene(),cam=new T.PerspectiveCamera(S.fov,2,.1,700);scene.add(cam);
const hemi=new T.HemisphereLight(0xbfd8ff,0x556644,.9),sun=new T.DirectionalLight(0xffeedd,.8);scene.add(hemi,sun);
const torchL=new T.PointLight(0xffaa55,0,22),fireL=new T.PointLight(0xff7722,0,16);cam.add(torchL);scene.add(fireL);
function resize(){R.setPixelRatio(Math.min(devicePixelRatio,2)*S.gfx);R.setSize(innerWidth,innerHeight,false);cam.aspect=innerWidth/innerHeight;cam.updateProjectionMatrix()}
addEventListener('resize',resize);resize();
{const N=150,g=new T.PlaneGeometry(SZ,SZ,N,N);g.rotateX(-Math.PI/2);const p=g.attributes.position,c=new Float32Array(p.count*3);
 for(let i=0;i<p.count;i++){const x=p.getX(i),z=p.getZ(i),h=H(x,z);p.setY(i,h);const b=biome(z);let r,gg,bb;
  if(h<1.8){r=.78;gg=.7;bb=.45}else if(b==='arctic'){r=.9;gg=.93;bb=.97}else if(b==='desert'){r=.76;gg=.62;bb=.35}else if(h>13){r=.5;gg=.5;bb=.5}else{const v=hash(x,z)*.1;r=.25+v;gg=.5+v;bb=.2}
  c[i*3]=r;c[i*3+1]=gg;c[i*3+2]=bb}
 g.setAttribute('color',new T.BufferAttribute(c,3));g.computeVertexNormals();scene.add(new T.Mesh(g,new T.MeshLambertMaterial({vertexColors:true})))}
const water=new T.Mesh(new T.PlaneGeometry(3000,3000).rotateX(-Math.PI/2),new T.MeshLambertMaterial({color:0x2a6f97,transparent:true,opacity:.8}));scene.add(water);
// ресурсы
const res=[],trunkI=new T.InstancedMesh(new T.CylinderGeometry(.25,.35,4,5).translate(0,2,0),new T.MeshLambertMaterial({color:0x6b4a2b}),D.world.treeCount),
 crownI=new T.InstancedMesh(new T.ConeGeometry(2,5,6).translate(0,5.5,0),new T.MeshLambertMaterial({color:0x2f6b2f}),D.world.treeCount),
 stoneI=new T.InstancedMesh(new T.DodecahedronGeometry(1.4,0),new T.MeshLambertMaterial({color:0x9a9a9a}),D.world.rockCount),
 metalI=new T.InstancedMesh(new T.DodecahedronGeometry(1.4,0),new T.MeshLambertMaterial({color:0x8a5a3a}),D.world.metalCount);
[trunkI,crownI,stoneI,metalI].forEach(m=>m.frustumCulled=false);scene.add(trunkI,crownI,stoneI,metalI);
const M4=new T.Matrix4(),Z4=new T.Matrix4().makeScale(0,0,0);
function place(inst,i,x,y,z,s,ry){M4.compose(new T.Vector3(x,y,z),new T.Quaternion().setFromEuler(new T.Euler(0,ry,0)),new T.Vector3(s,s,s));inst.setMatrixAt(i,M4)}
function land(){for(let k=0;k<80;k++){const x=rnd(-SZ/2,SZ/2)*.9,z=rnd(-SZ/2,SZ/2)*.9,h=H(x,z);if(h>2.4&&hubD(x,z)>D.hub.r&&!D.radZones.some(r=>Math.hypot(x-r.x,z-r.z)<r.r))return{x,z,h}}return{x:0,z:0,h:H(0,0)}}
for(let i=0;i<D.world.treeCount;i++){const p=land(),s=rnd(.8,1.4);place(trunkI,i,p.x,p.h,p.z,s,0);place(crownI,i,p.x,p.h,p.z,s,0);res.push({k:'tree',i,x:p.x,y:p.h,z:p.z,r:1,left:300,max:300,inst:[trunkI,crownI],s})}
for(let i=0;i<D.world.rockCount;i++){const p=land(),s=rnd(1,1.7);place(stoneI,i,p.x,p.h+.5,p.z,s,rnd(0,6));res.push({k:'stone',i,x:p.x,y:p.h,z:p.z,r:1.6*s,left:800,max:800,inst:[stoneI],s,hs:rnd(0,6.28)})}
for(let i=0;i<D.world.metalCount;i++){const p=land(),s=rnd(1,1.5);place(metalI,i,p.x,p.h+.5,p.z,s,rnd(0,6));res.push({k:'metal',i,x:p.x,y:p.h,z:p.z,r:1.6*s,left:600,max:600,inst:[metalI],s,hs:rnd(0,6.28)})}
[trunkI,crownI,stoneI,metalI].forEach(m=>m.instanceMatrix.needsUpdate=true);
const hotspot=new T.Mesh(new T.SphereGeometry(.2,8,8),new T.MeshBasicMaterial({color:0xffe14a}));hotspot.visible=false;scene.add(hotspot);
// монументы
function box(w,h,d,col,x,y,z){const m=new T.Mesh(new T.BoxGeometry(w,h,d),new T.MeshLambertMaterial({color:col}));m.position.set(x,y,z);scene.add(m);return m}
{const hx=D.hub.x,hz=D.hub.z,hy=H(hx,hz);box(10,4,8,0xb08850,hx,hy+2,hz);box(11,.6,9,0x6b3b2b,hx,hy+4.3,hz);box(1,2,1,0x44aa77,hx+7,hy+1,hz);
 const rz=D.radZones[0],ry=H(rz.x,rz.z);const cyl=new T.Mesh(new T.CylinderGeometry(rz.r,rz.r,60,20,1,true),new T.MeshBasicMaterial({color:0xff2200,transparent:true,opacity:.12,side:T.DoubleSide}));cyl.position.set(rz.x,ry+25,rz.z);scene.add(cyl);box(14,18,14,0x555555,rz.x,ry+9,rz.z)}
const hubY=H(D.hub.x,D.hub.z);
// ---------- состояние ----------
const P={x:0,y:5,z:0,vy:0,yaw:0,pitch:0,hp:100,food:100,water:100,temp:30,rad:0,bleed:0,wounded:0,dead:false,swim:false,sel:0,crouch:false,ground:false,spawnT:0,wet:0,lastHead:false};
const inv=Array(30).fill(null),worn={head:null,body:null},learned=new Set(['bandage']);
D.recipes.forEach(r=>{if(!r.bp)learned.add(r.id)});
let pieces=new Map(),deploys=[],core=null,spawnPt=null,bedCd=0,gameT=0,queue=[],started=false,paused=true,nextRaid=D.bots.raidEvery,raidWarn=false,saveT=0,decT=0;
const mags={};let recoilK=0,swingT=0,fireCd=0,ads=false,firing=false,hsChain=0;
const log=t=>{const e=document.createElement('div');e.textContent=t;$('log').appendChild(e);setTimeout(()=>e.remove(),4500);while($('log').children.length>5)$('log').firstChild.remove()};
// ---------- инвентарь ----------
function add(id,n,d){const st=IT[id].st;for(let i=0;i<30&&n>0;i++){const s=inv[i];if(s&&s.id===id&&s.n<st){const a=Math.min(st-s.n,n);s.n+=a;n-=a}}
 for(let i=0;i<30&&n>0;i++)if(!inv[i]){const a=Math.min(st,n);inv[i]={id,n:a,d:d||IT[id].dur||0};n-=a}return n===0}
const count=id=>inv.reduce((a,s)=>a+(s&&s.id===id?s.n:0),0);
function take(id,n){for(let i=0;i<30&&n>0;i++){const s=inv[i];if(s&&s.id===id){const a=Math.min(s.n,n);s.n-=a;n-=a;if(!s.n)inv[i]=null}}}
const canPay=c=>Object.keys(c).every(k=>count(k)>=c[k]),pay=c=>Object.keys(c).forEach(k=>take(k,c[k]));
const held=()=>inv[P.sel];
function fmt(c){return Object.keys(c).map(k=>IT[k].n+' '+c[k]).join(', ')}
// ---------- постройки ----------
const tierMat=D.tiers.map(t=>new T.MeshLambertMaterial({color:t.col})),UB=new T.BoxGeometry(1,1,1),C=D.build.cell,LH=D.build.levelH;
const gOK=new T.MeshBasicMaterial({color:0x33ff66,transparent:true,opacity:.45}),gBad=new T.MeshBasicMaterial({color:0xff3344,transparent:true,opacity:.45});
let bType='found',solids=[],dirty=true;
const key=(t,i,j,L)=>t+','+i+','+j+','+L;
function parts(p){const{type,i,j,d,L,y}=p;
 if(type==='found')return[{c:[i*C+C/2,y-.75,j*C+C/2],s:[C,1.5,C]}];
 if(type==='roof')return[{c:[i*C+C/2,y-.15,j*C+C/2],s:[C,.3,C]}];
 const a=d===0?[i*C,j*C]:[i*C,j*C];const px=d===0?(x=>[i*C+x,y+1.5,j*C]):(x=>[i*C,y+1.5,j*C+x]);
 if(type==='wall')return[{c:px(C/2),s:d===0?[C,3,.3]:[.3,3,C]}];
 const sz=(w,h)=>d===0?[w,h,.3]:[.3,h,w];const pp=(x,yy)=>{const q=px(x);q[1]=y+yy;return q};
 return[{c:pp(.5,1.5),s:sz(1,3)},{c:pp(2.5,1.5),s:sz(1,3)},{c:pp(1.5,2.5),s:sz(1,1)},{c:pp(1.5,1),s:sz(1,2),door:true}]}
function mkPiece(o){const p=Object.assign({tier:0,hp:D.tiers[0].hp,open:false},o);p.k=key(p.type,p.i,p.j,p.L);if(p.type!=='found'&&p.type!=='roof')p.k=key('w'+p.d,p.i,p.j,p.L);else p.k=key(p.type==='found'?'f':'r',p.i,p.j,p.L);
 const g=new T.Group();p.parts=parts(p);p.meshes=p.parts.map(q=>{const m=new T.Mesh(UB,tierMat[p.tier]);m.position.set(...q.c);m.scale.set(...q.s);if(q.door)m.material=tierMat[1];g.add(m);return m});
 scene.add(g);p.g=g;pieces.set(p.k,p);dirty=true;refreshDoor(p);return p}
function refreshDoor(p){p.parts.forEach((q,n)=>{if(q.door)p.meshes[n].visible=!p.open});p.boxes=p.parts.filter(q=>!q.door||!p.open).map(q=>new T.Box3(new T.Vector3(q.c[0]-q.s[0]/2,q.c[1]-q.s[1]/2,q.c[2]-q.s[2]/2),new T.Vector3(q.c[0]+q.s[0]/2,q.c[1]+q.s[1]/2,q.c[2]+q.s[2]/2)));dirty=true}
function setTier(p,t){p.tier=t;p.hp=D.tiers[t].hp;p.meshes.forEach((m,n)=>{if(!p.parts[n].door)m.material=tierMat[t]})}
function foundAt(i,j){return pieces.get(key('f',i,j,0))}
function support(o){ // вернёт {y,st} или null
 const{type,i,j,d,L}=o;
 if(type==='found')return{y:o.y,st:100};
 if(type==='roof'){let b=null;[[0,i,j],[0,i,j+1],[1,i,j],[1,i+1,j]].forEach(([dd,ii,jj])=>{const w=pieces.get(key('w'+dd,ii,jj,L-1));if(w&&(!b||w.st>b.st))b=w});return b?{y:b.y+LH,st:b.st*D.build.stabDrop}:null}
 if(L===0){const f=d===0?(foundAt(i,j)||foundAt(i,j-1)):(foundAt(i,j)||foundAt(i-1,j));return f?{y:f.y,st:100}:null}
 const w=pieces.get(key('w'+d,i,j,L-1));return w?{y:w.y+LH,st:w.st*D.build.stabDrop}:null}
function rebuildSolids(){solids=[];pieces.forEach(p=>p.boxes.forEach(b=>solids.push({b,p})));dirty=false}
function destroyPiece(p){scene.remove(p.g);pieces.delete(p.k);dirty=true;
 let ch=true;while(ch){ch=false;pieces.forEach(q=>{if(q.type!=='found'){const s=support(q);if(!s||s.st<D.build.minStab){scene.remove(q.g);pieces.delete(q.k);ch=true;log('Деталь рухнула: потеряна опора')}}})}}
function dmgPiece(p,d,type){let v=d;if(type==='explosion')v=d*(1-D.tiers[p.tier].prot);p.hp-=v;if(p.hp<=0)destroyPiece(p)}
// ---------- рэйкасты ----------
const ray=new T.Ray(),V1=new T.Vector3(),V2=new T.Vector3();
function aim(){cam.getWorldDirection(V2);return V2}
function rayPieces(o,d,max){if(dirty)rebuildSolids();ray.set(o,d);let best=null,bt=max;for(const s of solids){const hit=ray.intersectBox(s.b,V1);if(hit){const t=hit.distanceTo(o);if(t<bt){bt=t;best={t,p:s.p}}}}return best}
function rayGround(o,d,max){let t=0;while(t<max){const x=o.x+d.x*t,y=o.y+d.y*t,z=o.z+d.z*t;if(y<gY(x,z))return t;t+=.4}return null}
function gY(x,z){let h=Math.max(H(x,z),0);const ci=Math.floor(x/C),cj=Math.floor(z/C),f=foundAt(ci,cj);if(f&&f.y>h)h=f.y;return h}
// ---------- коллизии игрока ----------
function collide(){if(dirty)rebuildSolids();const r=.4;for(const s of solids){const b=s.b;if(P.y+1.7<b.min.y+.05||P.y>b.max.y-.1||s.p.type==='found'&&P.y>=b.max.y-.4)continue;
 const cx=clamp(P.x,b.min.x,b.max.x),cz=clamp(P.z,b.min.z,b.max.z),dx=P.x-cx,dz=P.z-cz,dd=dx*dx+dz*dz;
 if(dd<r*r){if(dd>1e-6){const l=Math.sqrt(dd);P.x=cx+dx/l*r;P.z=cz+dz/l*r}else{const l=Math.min(P.x-b.min.x,b.max.x-P.x),m=Math.min(P.z-b.min.z,b.max.z-P.z);if(l<m)P.x+=(P.x-(b.min.x+b.max.x)/2>0?1:-1)*(l+r);else P.z+=(P.z-(b.min.z+b.max.z)/2>0?1:-1)*(m+r)}}}}
// ---------- сущности ----------
const animals=[],bots=[],barrels=[],bulletsPool=[];
function hum(col){const g=new T.Group(),mt=new T.MeshLambertMaterial({color:col});const b=new T.Mesh(UB,mt);b.scale.set(.6,.9,.35);b.position.y=1.15;const l=new T.Mesh(UB,mt);l.scale.set(.5,.8,.3);l.position.y=.4;const h=new T.Mesh(new T.SphereGeometry(.25,8,8),new T.MeshLambertMaterial({color:0xddb08a}));h.position.y=1.85;const gun=new T.Mesh(UB,new T.MeshLambertMaterial({color:0x222222}));gun.scale.set(.1,.12,.7);gun.position.set(.3,1.3,.4);g.add(b,l,h,gun);return g}
function spawnAnimal(k,x,z){const a=D.animals[k],g=new T.Group(),m=new T.MeshLambertMaterial({color:a.col});const b=new T.Mesh(UB,m);b.scale.set(.6*a.s,.6*a.s,1.2*a.s);b.position.y=.6*a.s;const h=new T.Mesh(UB,m);h.scale.set(.35*a.s,.35*a.s,.4*a.s);h.position.set(0,.8*a.s,.7*a.s);g.add(b,h);scene.add(g);
 animals.push({k,d:a,g,x,z,y:H(x,z),hp:a.hp,st:'idle',tx:x,tz:z,t:0,cd:0,h:1.2*a.s,r:.7*a.s,dead:false,rt:0})}
for(let i=0;i<D.world.animals;i++){const p=land();const z=p.z,k=z<-120?(Math.random()<.5?'pbear':'wolf'):['chicken','boar','deer','wolf','bear','deer','chicken'][i%7];spawnAnimal(k,p.x,p.z)}
const barrelM=new T.MeshLambertMaterial({color:0x3a6b9a}),crateM=new T.MeshLambertMaterial({color:0x55663a});
function mkBarrel(x,z,kind){const m=new T.Mesh(kind==='crate'?new T.BoxGeometry(1,.8,1):new T.CylinderGeometry(.4,.4,.9,8),kind==='crate'?crateM:barrelM);const y=H(x,z);m.position.set(x,y+.45,z);scene.add(m);barrels.push({x,z,y,m,kind,cd:0})}
for(let i=0;i<D.world.barrels;i++){const p=land();mkBarrel(p.x,p.z,'barrel')}
for(let i=0;i<6;i++)mkBarrel(D.hub.x+rnd(-12,12),D.hub.z+rnd(-12,12),'crate');for(let i=0;i<5;i++){const z=D.radZones[0];mkBarrel(z.x+rnd(-20,20),z.z+rnd(-20,20),'crate')}
function rollLoot(tbl){tbl.forEach(([id,a,b,ch])=>{if(Math.random()<ch){const n=Math.round(rnd(a,b));add(id,n);log('+'+n+' '+IT[id].n)}})}
const projM=new T.MeshBasicMaterial({color:0xffdd88});for(let i=0;i<48;i++){const m=new T.Mesh(new T.BoxGeometry(.05,.05,.6),projM);m.visible=false;scene.add(m);bulletsPool.push({on:false,m,p:new T.Vector3(),v:new T.Vector3(),dmg:0,life:0,arrow:false,own:'p',g:0})}
function shoot(from,dir,speed,dmg,arrow,own){const b=bulletsPool.find(x=>!x.on);if(!b)return;b.on=true;b.p.copy(from);b.v.copy(dir).multiplyScalar(speed);b.dmg=dmg;b.life=3;b.arrow=arrow;b.own=own;b.g=arrow?9.8:6;b.m.visible=true}
// урон
function armorMul(type){let m=1;['head','body'].forEach(s=>{const a=worn[s]&&D.armor[worn[s]];if(a&&a[type]!=null)m*=(1-a[type])});return m}
function hurt(d,type,head){if(P.dead)return;if(hubD(P.x,P.z)<D.hub.r&&type!=='fall'&&type!=='cold'&&type!=='radiation')return;P.hp-=d*armorMul(type);P.lastHead=!!head;flash();if(S.vib&&navigator.vibrate)navigator.vibrate(30);if(P.hp<=0)downed()}
function flash(){const e=$('hurt');e.style.opacity=.6;setTimeout(()=>e.style.opacity=0,150)}
function downed(){if(!P.wounded&&!P.lastHead&&Math.random()<D.surv.woundChance){P.wounded=D.surv.woundedTime;P.hp=10;log('Ты ранен! Ползёшь…');return}die()}
function die(){P.dead=true;P.wounded=0;$('death').style.display='flex';const cd=Math.max(0,Math.ceil(bedCd-gameT));$('resBed').disabled=!spawnPt||cd>0;$('resBed').textContent='Спальник'+(cd>0?' ('+cd+' c)':'');for(let i=0;i<30;i++)inv[i]=null;worn.head=worn.body=null;firing=false;renderHot()}
function respawn(bed){P.dead=false;P.hp=60;P.food=60;P.water=60;P.rad=0;P.bleed=0;P.temp=30;if(bed&&spawnPt){P.x=spawnPt.x;P.z=spawnPt.z;P.y=gY(P.x,P.z)+1}else{const a=rnd(0,6.28);let r=SZ/2*.85,x,z;for(r=SZ/2*.92;r>40;r-=4){x=Math.cos(a)*r;z=Math.sin(a)*r;const h=H(x,z);if(h>.5&&h<2.5)break}P.x=x;P.z=z;P.y=gY(x,z)+1}
 add('rock',1);add('torch',1);$('death').style.display='none';renderHot();log('Ты на берегу. Найди дерево и камень.')}
// ---------- использование предметов ----------
function consume(s){s.n--;if(s.n<=0)inv[P.sel]=null;renderHot()}
function wearTool(s,mult){const it=IT[s.id];s.d-=(mult||1)*10;if(s.d<=0){log(it.n+' сломан');inv[P.sel]=null;renderHot()}}
function press(){ // однократные действия
 if(P.dead||P.wounded)return;const s=held();if(!s)return;const it=IT[s.id];
 if(it.t==='food'){P.food=clamp(P.food+it.f,0,100);P.water=clamp(P.water+(it.w||0),0,100);if(it.h<0)hurt(-it.h,'melee');else P.hp=clamp(P.hp+it.h,0,100);consume(s)}
 else if(it.t==='heal'){P.hp=clamp(P.hp+(it.hp||0),0,100);if(it.stop)P.bleed=0;if(it.rad)P.rad=Math.max(0,P.rad+it.rad);if(it.w)P.water=clamp(P.water+it.w,0,100);consume(s);log('Лечение')}
 else if(it.t==='armor'){const old=worn[it.slot];worn[it.slot]=old===s.id?null:s.id;log(old===s.id?'Снято':'Надето: '+it.n)}
 else if(it.t==='dep')deploy(s,it);
 else if(it.t==='plan')placeBuild();
 else if(it.t==='hammer')hammerUse();}
function nearFire(){return deploys.some(d=>d.k==='campfire'&&Math.hypot(d.x-P.x,d.z-P.z)<D.surv.fireRadius)}
function nearForge(){let l=0;deploys.forEach(d=>{if(d.k==='forge'&&Math.hypot(d.x-P.x,d.z-P.z)<8)l=Math.max(l,d.lv)});return l}
const ghost=new T.Mesh(UB,gOK);ghost.visible=false;scene.add(ghost);let gInfo=null;
function updateGhost(){const s=held(),it=s&&IT[s.id];gInfo=null;ghost.visible=false;$('wheel').style.display='none';
 if(!it||(it.t!=='plan'&&it.t!=='dep')||P.dead)return;const d=aim(),o=cam.position;let t=6;const rp=rayPieces(o,d,6),rg=rayGround(o,d,6);if(rp)t=Math.min(t,rp.t);if(rg!=null)t=Math.min(t,rg);
 const ax=o.x+d.x*t,ay=o.y+d.y*t,az=o.z+d.z*t;
 if(it.t==='dep'){if(it.dep==='core'){const ci=Math.floor(ax/C),cj=Math.floor(az/C),f=foundAt(ci,cj);gInfo={dep:true,x:f?ci*C+C/2:ax,y:f?f.y:gY(ax,az),z:f?cj*C+C/2:az,ok:!!f&&!core};ghost.scale.set(1,1.2,.6)}else{gInfo={dep:true,x:ax,y:gY(ax,az),z:az,ok:H(ax,az)>.3};ghost.scale.set(1,.6,1)}
  ghost.position.set(gInfo.x,gInfo.y+.4,gInfo.z);ghost.material=gInfo.ok?gOK:gBad;ghost.visible=true;return}
 $('wheel').style.display='flex';const ci=Math.floor(ax/C),cj=Math.floor(az/C);let o2;
 if(bType==='found'){const cx=[ci*C,ci*C+C],cz=[cj*C,cj*C+C];const hs=[H(cx[0],cz[0]),H(cx[1],cz[0]),H(cx[0],cz[1]),H(cx[1],cz[1])];let fy=Math.max(...hs)+.25;const nb=foundAt(ci-1,cj)||foundAt(ci+1,cj)||foundAt(ci,cj-1)||foundAt(ci,cj+1);if(nb)fy=nb.y;
  o2={type:'found',i:ci,j:cj,d:0,L:0,y:fy};o2.ok=!foundAt(ci,cj)&&Math.max(...hs)-Math.min(...hs)<3&&Math.min(...hs)>.2;gInfo={b:o2}}
 else if(bType==='roof'){let L=1;const nf=foundAt(ci,cj)||null;let ref=null;pieces.forEach(p=>{if(p.type==='found'&&Math.hypot(p.i*C+1.5-ax,p.j*C+1.5-az)<6)ref=p});if(ref)L=clamp(Math.round((ay-ref.y)/LH),1,D.build.maxLevels);o2={type:'roof',i:ci,j:cj,d:0,L};const s2=support(o2);o2.y=s2?s2.y:0;o2.st=s2?s2.st:0;o2.ok=!!s2&&s2.st>=D.build.minStab&&!pieces.has(key('r',ci,cj,L));gInfo={b:o2}}
 else{const fx=ax-ci*C,fz=az-cj*C,ds=[[fx,0,ci,cj],[C-fx,0,ci+1,cj],[fz,1,ci,cj],[C-fz,1,ci,cj+1]].sort((a,b)=>a[0]-b[0])[0];const wi=ds[1]===1?ds[2]:ds[2],dd=ds[1]===0?1:0;
  // dir0 = вдоль x на линии z=j*C ; dir1 = вдоль z на линии x=i*C
  const dir=ds[1]===0?1:0;const i2=ds[2],j2=ds[3];let ref=null,bd=1e9;pieces.forEach(p=>{if(p.type==='found'){const dq=Math.hypot(p.i*C+1.5-ax,p.j*C+1.5-az);if(dq<bd){bd=dq;ref=p}}});let L=ref?clamp(Math.floor((ay-ref.y+.4)/LH),0,D.build.maxLevels-1):0;
  o2={type:bType==='door'?'door':'wall',i:i2,j:j2,d:dir,L};const s2=support(o2);o2.y=s2?s2.y:0;o2.st=s2?s2.st:0;o2.ok=!!s2&&s2.st>=D.build.minStab&&!pieces.has(key('w'+dir,i2,j2,L));gInfo={b:o2}}
 const pp=parts(o2.type==='found'||o2.type==='roof'?o2:o2),q=pp[0];ghost.scale.set(...(pp.length>1?[3,3,.3]:q.s));if(pp.length>1&&o2.d===1)ghost.scale.set(.3,3,3);ghost.position.set(...(pp.length>1?(o2.d===0?[o2.i*C+1.5,o2.y+1.5,o2.j*C]:[o2.i*C,o2.y+1.5,o2.j*C+1.5]):q.c));ghost.material=o2.ok?gOK:gBad;ghost.visible=true}
function placeBuild(){if(!gInfo||!gInfo.b)return;const b=gInfo.b;if(!b.ok){log('Нельзя поставить сюда');return}if(!canPay(D.tiers[0].cost)){log('Нужно: '+fmt(D.tiers[0].cost));return}pay(D.tiers[0].cost);const p=mkPiece(b);p.st=b.st!==undefined?b.st:100;p.y=b.y;renderHot()}
function hammerUse(){const r=rayPieces(cam.position,aim(),5);if(!r){return}const p=r.p;if(p.tier>=D.tiers.length-1){p.hp=D.tiers[p.tier].hp;log('Починено');return}const nt=D.tiers[p.tier+1];if(!canPay(nt.cost)){log('Нужно: '+fmt(nt.cost));return}pay(nt.cost);setTier(p,p.tier+1);log('Улучшено: '+nt.n);renderHot()}
function deploy(s,it){if(!gInfo||!gInfo.dep||!gInfo.ok){log(it.dep==='core'?'Ядро ставится на фундамент (одно на базу)':'Нельзя поставить');return}
 const d={k:it.dep,x:gInfo.x,y:gInfo.y,z:gInfo.z,lv:it.lv||0,hp:it.dep==='core'?D.core.hp:100,t:0};mkDeploy(d);deploys.push(d);if(it.dep==='core'){core=d;d.stock={wood:0,stone:0,shards:0,starsteel:0};log('Ядро установлено: радиус привилегии '+D.core.radius+' м')}
 if(it.dep==='bedroll'){spawnPt={x:d.x,z:d.z};log('Точка возрождения сохранена')}if(it.dep==='charge'){d.fuse=D.explosive.charge.fuse;log('Заряд активирован!')}consume(s)}
function mkDeploy(d){const cols={core:0x3366cc,bedroll:0xcc5544,campfire:0xdd6622,forge:0x777788,charge:0xcc2222};const g=box(d.k==='forge'?1.6:1,d.k==='core'?1.2:d.k==='bedroll'?.2:.7,d.k==='bedroll'?1.8:1,cols[d.k]||0x888888,d.x,d.y+(d.k==='core'?.6:.35),d.z);d.m=g}
function interact(){if(P.dead)return;let best=null,bd=3;
 barrels.forEach(b=>{if(b.cd<=0){const dd=Math.hypot(b.x-P.x,b.z-P.z);if(dd<bd){bd=dd;best={t:'barrel',b}}}});
 deploys.forEach(d=>{const dd=Math.hypot(d.x-P.x,d.z-P.z);if(dd<bd&&(d.k==='core'||d.k==='campfire')){bd=dd;best={t:d.k,d}}});
 animals.forEach(a=>{if(a.dead){const dd=Math.hypot(a.x-P.x,a.z-P.z);if(dd<bd){bd=dd;best={t:'corpse',a}}}});
 bots.forEach(a=>{if(a.dead){const dd=Math.hypot(a.x-P.x,a.z-P.z);if(dd<bd){bd=dd;best={t:'bot',a}}}});
 const hd=Math.hypot(D.hub.x+7-P.x,D.hub.z-P.z);if(hd<3.5&&hd<bd){best={t:'shop'};bd=hd}
 const rp=rayPieces(cam.position,aim(),4);if(rp&&(rp.p.type==='door')&&(!best||rp.t<bd)){rp.p.open=!rp.p.open;refreshDoor(rp.p);return}
 if(!best)return;
 if(best.t==='barrel'){rollLoot(D.loot[best.b.kind]);best.b.cd=rnd(120,480)*D.time.respawnScale*(best.b.kind==='crate'?2:1);best.b.m.visible=false}
 else if(best.t==='corpse'){const a=best.a;Object.keys(a.d.loot).forEach(k=>{add(k,a.d.loot[k]);});log('Разделано: '+a.d.n);a.rt=1;scene.remove(a.g);animals.splice(animals.indexOf(a),1);renderHot()}
 else if(best.t==='bot'){const a=best.a;rollLoot([['ammo556',10,30,.7],['shards',20,60,.8],['slag',5,20,.6],['bandage',1,3,.5],['wood',20,80,.5]]);if(Math.random()<.2)add('hornet',1);scene.remove(a.g);bots.splice(bots.indexOf(a),1);renderHot()}
 else if(best.t==='campfire'){const m=count('meat'),w=count('wood');const n=Math.min(m,Math.floor(w/1),10);if(n<=0){log('Нужны сырое мясо и дерево');return}take('wood',n);take('meat',n);log('Жарится…');setTimeout(()=>{add('cooked',n);renderHot();log('Готово: жареное мясо x'+n)},5000)}
 else if(best.t==='core'){openCore()}else if(best.t==='shop')openShop();renderHot()}
// ---------- ближний бой / сбор ----------
function facing(x,z,max,dotMin){const dx=x-P.x,dz=z-P.z,dd=Math.hypot(dx,dz);if(dd>max)return false;return(dx*-Math.sin(P.yaw)+dz*-Math.cos(P.yaw))/Math.max(dd,.01)>dotMin}
function melee(s,it){swingT=.25;let tgt=null,td=1e9;
 animals.forEach(a=>{if(!a.dead&&facing(a.x,a.z,2.8,.6)){const dd=Math.hypot(a.x-P.x,a.z-P.z);if(dd<td){td=dd;tgt={t:'a',a}}}});
 bots.forEach(a=>{if(!a.dead&&facing(a.x,a.z,2.8,.6)){const dd=Math.hypot(a.x-P.x,a.z-P.z);if(dd<td){td=dd;tgt={t:'a',a}}}});
 if(!tgt)res.forEach(n=>{if(n.left>0&&facing(n.x,n.z,3+n.r,.7)){const dd=Math.hypot(n.x-P.x,n.z-P.z);if(dd<td){td=dd;tgt={t:'r',n}}}});
 const rp=rayPieces(cam.position,aim(),3);if(rp&&(!tgt||rp.t<td)){tgt={t:'p',p:rp.p}}
 if(!tgt){hsChain=0;return}wearTool(s,tgt.t==='r'?1:.5);
 if(tgt.t==='a')hitEnt(tgt.a,it.dmg,'melee',false,it.bleed);
 else if(tgt.t==='p')dmgPiece(tgt.p,it.dmg*.5,'melee');
 else{const n=tgt.n;let mult=1;
  if(n.k!=='tree'){const hp=new T.Vector3(n.x+Math.cos(n.hs)*n.r*.8,n.y+.9*n.s,n.z+Math.sin(n.hs)*n.r*.8).project(cam);const dd=Math.hypot(hp.x*innerWidth/2,hp.y*innerHeight/2);if(dd<80&&hp.z<1){hsChain=Math.min(2,hsChain+.5);mult=1+hsChain;n.hs=rnd(0,6.28);log('Хотспот x'+mult.toFixed(1))}else hsChain=0}
  const key2=n.k==='tree'?'wood':n.k==='stone'?'stone':'shards';let amt=Math.round((it.g[key2]||0)*mult*(1+(n.k==='tree'?0:0)));
  if(!amt){log(n.k==='tree'?'Нужен топор':'Нужна кирка');return}amt=Math.min(amt,n.left);n.left-=amt;add(key2,amt);if(n.k==='metal'&&Math.random()<.04)add('starsteel',1);
  if(n.left<=0){n.inst.forEach(m=>{m.setMatrixAt(n.i,Z4);m.instanceMatrix.needsUpdate=true});n.rt=300*D.time.respawnScale;log(n.k==='tree'?'Дерево срублено':'Руда исчерпана')}renderHot()}}
function hitEnt(e,d,type,head,bleed){if(e.dead)return;e.hp-=d*(head?2:1);if(e.isBot){e.alert=true}else{e.st=e.d.type==='prey'?'flee':'chase';e.t=6}showHit(head);if(e.hp<=0){e.dead=true;e.g.rotation.z=Math.PI/2;e.g.position.y=H(e.x,e.z)+.3;if(e.isBot)log('[BOT] '+e.name+' убит');else log(e.d.n+' убит (E — разделать)')}}
function showHit(h){const e=$('hit');e.style.opacity=1;e.style.borderColor=h?'#f33':'#fff';setTimeout(()=>e.style.opacity=0,120);if(S.vib&&navigator.vibrate)navigator.vibrate(10)}
// ---------- стрельба ----------
function fireTick(dt){if(P.dead||P.wounded||!firing)return;const s=held();if(!s)return;const it=IT[s.id];fireCd-=dt;
 if(fireCd>0)return;
 if(it.t==='tool'){fireCd=it.rate;melee(s,it)}
 else if(it.t==='bow'){if(count('arrow')<1){log('Нет стрел');fireCd=.5;return}take('arrow',1);fireCd=it.rate;const d=aim().clone();shoot(cam.position,d,it.speed,it.dmg,true,'p');renderHot()}
 else if(it.t==='gun'){const m=mags[s.id]||(mags[s.id]={n:0,rl:0});if(m.rl>0)return;if(m.n<=0){reload();fireCd=.3;return}m.n--;fireCd=60/it.rpm;
  const sp=(it.spread*(ads?.4:1)*(P.crouch?.7:1)+(moving?1.2:0)+recoilK*.3)*Math.PI/180;const d=aim().clone();d.x+=rnd(-sp,sp);d.y+=rnd(-sp,sp);d.z+=rnd(-sp,sp);d.normalize();
  shoot(cam.position,d,it.speed,it.dmg,false,'p');recoilK=Math.min(recoilK+1,12);const a=1-S.assist/200;P.pitch+=it.recoil[1]*.012*a*(1+recoilK*.05);P.yaw+=it.recoil[0]*.012*a*(Math.random()<.5?1:-1)*(1+recoilK*.04);wearTool(s,.15);renderHot()}
 else if(!it.t||it.t==='food'||it.t==='heal'||it.t==='plan'||it.t==='hammer'||it.t==='dep'||it.t==='armor'){}}
function reload(){const s=held();if(!s)return;const it=IT[s.id];if(it.t!=='gun')return;const m=mags[s.id]||(mags[s.id]={n:0,rl:0});if(m.rl>0||m.n>=it.mag)return;const need=it.mag-m.n,have=Math.min(need,count(it.ammo));if(have<=0){log('Нет патронов');return}m.rl=it.reload;m.pend=have}
function updBullets(dt){for(const b of bulletsPool){if(!b.on)continue;b.life-=dt;if(b.life<=0){b.on=false;b.m.visible=false;continue}
 const steps=Math.ceil(b.v.length()*dt/.6);const sdt=dt/steps;for(let k=0;k<steps&&b.on;k++){b.v.y-=b.g*sdt;b.p.addScaledVector(b.v,sdt);const x=b.p.x,y=b.p.y,z=b.p.z;
  if(y<gY(x,z)||y<-1){b.on=false;break}
  if(dirty)rebuildSolids();V1.set(x,y,z);let hitB=false;for(const s of solids){if(s.b.containsPoint(V1)){dmgPiece(s.p,b.dmg*(b.own==='p'?.5:.3),'bullet');hitB=true;break}}if(hitB){b.on=false;break}
  if(b.own==='p'){const hitE=e=>{if(e.dead)return false;const dx=e.x-x,dz=e.z-z;if(dx*dx+dz*dz>(e.r||.5)*(e.r||.5))return false;if(y<e.y||y>e.y+e.h)return false;hitEnt(e,b.dmg,'bullet',y>e.y+e.h*.82);return true};if(animals.some(hitE)||bots.some(hitE)){b.on=false;break}}
  else{const dx=P.x-x,dz=P.z-z;if(dx*dx+dz*dz<.25&&y>P.y&&y<P.y+1.8){hurt(b.dmg,'bullet',y>P.y+1.55);b.on=false;break}}}
 b.m.visible=b.on;if(b.on){b.m.position.copy(b.p);b.m.lookAt(b.p.x+b.v.x,b.p.y+b.v.y,b.p.z+b.v.z)}}}
// ---------- ИИ ----------
let moving=false;
function updAnimals(dt){for(let n=animals.length-1;n>=0;n--){const a=animals[n];const dp=Math.hypot(a.x-P.x,a.z-P.z);a.g.visible=dp<160;if(a.dead||dp>110)continue;a.t-=dt;a.cd-=dt;
 if(a.st==='idle'||a.st==='wander'){if(a.t<=0){a.st=Math.random()<.5?'idle':'wander';a.t=rnd(2,6);a.tx=a.x+rnd(-14,14);a.tz=a.z+rnd(-14,14)}
  if(dp<14&&hubD(P.x,P.z)>D.hub.r){a.st=a.d.type==='prey'?'flee':'chase';a.t=8}}
 let tx=a.tx,tz=a.tz,sp=a.d.spd*.4;if(a.st==='flee'){tx=a.x+(a.x-P.x);tz=a.z+(a.z-P.z);sp=a.d.spd;if(a.t<=0)a.st='idle'}
 else if(a.st==='chase'){tx=P.x;tz=P.z;sp=a.d.spd;if(a.t<=0||dp>45||hubD(P.x,P.z)<D.hub.r||P.dead)a.st='idle';if(dp<1.8&&a.cd<=0){a.cd=1.2;hurt(a.d.dmg,'bite');if(a.d.bleed)P.bleed+=1}}
 else if(a.st==='idle')sp=0;
 const dx=tx-a.x,dz=tz-a.z,l=Math.hypot(dx,dz)||1;if(sp>0&&(l>1||a.st==='flee')){const nx=a.x+dx/l*sp*dt,nz=a.z+dz/l*sp*dt;if(H(nx,nz)>.6&&hubD(nx,nz)>D.hub.r*.9){a.x=nx;a.z=nz}a.g.rotation.y=Math.atan2(dx,dz)}
 a.y=gY(a.x,a.z);a.g.position.set(a.x,a.y,a.z)}}
function spawnRaider(x,z,nm){const g=hum(0x7a2222);scene.add(g);const b={isBot:true,name:nm,g,x,z,y:H(x,z),hp:D.bots.hp,r:.5,h:1.9,cd:rnd(1,2),alert:false,st:'march',fuse:0,dead:false,charge:false};bots.push(b);return b}
function updBots(dt){const tgt=core?{x:core.x,z:core.z}:null;for(let n=bots.length-1;n>=0;n--){const b=bots[n];if(b.dead){continue}const dp=Math.hypot(b.x-P.x,b.z-P.z);b.cd-=dt;
 const sees=dp<D.bots.sight&&!P.dead&&hubD(P.x,P.z)>D.hub.r;let dx,dz;
 if(sees&&(b.alert||dp<28)){dx=P.x-b.x;dz=P.z-b.z;const l=Math.hypot(dx,dz);if(l>D.bots.range*.5){b.x+=dx/l*3.5*dt;b.z+=dz/l*3.5*dt}
  if(b.cd<=0&&l<D.bots.range){b.cd=rnd(.5,.9);const o=new T.Vector3(b.x,b.y+1.4,b.z),dir=new T.Vector3(P.x-b.x+rnd(-1,1)*(1-D.bots.acc)*l*.12,P.y+1.2-(b.y+1.4),P.z-b.z+rnd(-1,1)*(1-D.bots.acc)*l*.12).normalize();shoot(o,dir,260,D.bots.dmg,false,'b')}}
 else if(tgt){dx=tgt.x-b.x;dz=tgt.z-b.z;const l=Math.hypot(dx,dz);if(l>3){b.x+=dx/l*3.2*dt;b.z+=dz/l*3.2*dt}else if(!b.charge){b.charge=true;b.fuse=D.explosive.charge.fuse;log('[BOT] '+b.name+' ставит заряд у твоей базы!')}else{b.fuse-=dt;if(b.fuse<=0){b.charge=false;b.fuse=1e9;explode(b.x,b.y+1,b.z,D.explosive.charge.dmg,4)}}}
 else{dx=P.x-b.x;dz=P.z-b.z;const l=Math.hypot(dx,dz);if(l>4){b.x+=dx/l*3*dt;b.z+=dz/l*3*dt}}
 b.y=gY(b.x,b.z);b.g.position.set(b.x,b.y,b.z);b.g.rotation.y=Math.atan2((dx||0),(dz||0))}}
function explode(x,y,z,dmg,r){const e=new T.Mesh(new T.SphereGeometry(r,10,10),new T.MeshBasicMaterial({color:0xffaa33,transparent:true,opacity:.7}));e.position.set(x,y,z);scene.add(e);setTimeout(()=>scene.remove(e),250);
 const list=[];pieces.forEach(p=>{const q=p.parts[0].c;if(Math.hypot(q[0]-x,q[2]-z)<r+1.5&&Math.abs(q[1]-y)<r+1.5)list.push(p)});list.forEach(p=>dmgPiece(p,dmg,'explosion'));
 deploys.forEach(d=>{if(d.k!=='charge'&&Math.hypot(d.x-x,d.z-z)<r+1){d.hp-=dmg*(d.k==='core'?1-D.core.prot:1);if(d.hp<=0){scene.remove(d.m);deploys.splice(deploys.indexOf(d),1);if(core===d){core=null;log('ЯДРО УНИЧТОЖЕНО')}}}});
 const dp=Math.hypot(P.x-x,P.z-z);if(dp<r+2)hurt(dmg*.3*(1-dp/(r+2)),'explosion')}
// ---------- выживание ----------
function dayPhase(){const c=D.time.day+D.time.night,t=(gameT%c);return{day:t<D.time.day,f:t<D.time.day?t/D.time.day:(t-D.time.day)/D.time.night}}
function survTick(dt){if(P.dead)return;const S2=D.surv;P.food=Math.max(0,P.food-S2.foodDrain*dt*(P.temp<S2.coldBelow?1.4:1));P.water=Math.max(0,P.water-S2.waterDrain*dt);
 const dph=dayPhase(),b=biome(P.z);let tt=b==='arctic'?-5:b==='desert'?32:20;if(!dph.day)tt-=12;if(P.swim)P.wet=1;else P.wet=Math.max(0,P.wet-dt*.02);tt-=P.wet*10;if(nearFire())tt+=25;if(worn.body==='radsuit')tt+=6;
 P.temp+=(tt-P.temp)*dt*.15;if(P.food<=0)P.hp-=S2.starveDmg*dt;if(P.water<=0)P.hp-=S2.starveDmg*dt;if(P.temp<S2.coldBelow)P.hp-=S2.coldDmg*dt*armorMul('cold')*(1+(S2.coldBelow-P.temp)*.05);
 if(P.bleed>0)P.hp-=S2.bleedDps*P.bleed*dt;
 let rz=0;D.radZones.forEach(z=>{const d=Math.hypot(P.x-z.x,P.z-z.z);if(d<z.r)rz=Math.max(rz,z.rad*(1-d/z.r*.5))});if(rz>0)P.rad=Math.min(500,P.rad+rz*.02*dt*armorMul('rad'));else P.rad=Math.max(0,P.rad-S2.radDecay*dt);if(P.rad>25)P.hp-=P.rad*S2.radDmg*dt*.1;
 const heal=P.food>20&&P.water>30&&P.temp>=8&&P.bleed<=0&&P.rad<25&&P.wounded<=0;if(heal&&P.hp<100)P.hp=Math.min(100,P.hp+(nearFire()?S2.regenFire:S2.regen)*dt);
 if(P.wounded>0){if(P.hp<=0){die();return}P.wounded-=dt;if(P.wounded<=0){const ch=.2+.25*(P.food>80&&P.water>80?1:0);if(Math.random()<ch){P.hp=20;P.wounded=0;log('Ты поднялся')}else die()}}
 else if(P.hp<=0)downed()}
function decayTick(dt){const dec=D.time.decayScale;let need={};
 const inR=p=>core&&Math.hypot(p.parts[0].c[0]-core.x,p.parts[0].c[2]-core.z)<D.core.radius;
 pieces.forEach(p=>{const t=D.tiers[p.tier],r=Object.keys(t.cost)[0],a=t.cost[r]*D.core.upkeepPerHour*dt/3600;if(inR(p)&&core.stock[r]!==undefined&&core.stock[r]>=a){core.stock[r]-=a}else{p.hp-=t.hp*dt/(t.decay*dec);if(p.hp<=0)destroyPiece(p)}})}
// ---------- UI ----------
function renderHot(){const h=$('hotbar');h.innerHTML='';for(let i=0;i<6;i++){const s=inv[i],e=document.createElement('div');e.className='slot'+(i===P.sel?' sel':'');e.innerHTML=s?'<b>'+IT[s.id].n+'</b>'+(IT[s.id].st>1?'<i>'+s.n+'</i>':'')+(mags[s.id]&&IT[s.id].t==='gun'?'<i>'+mags[s.id].n+'/'+count(IT[s.id].ammo)+'</i>':''):'';e.ontouchstart=ev=>{ev.preventDefault();P.sel=i;renderHot()};e.onclick=()=>{P.sel=i;renderHot()};h.appendChild(e)}
 if($('inv').style.display==='block')renderInv()}
let selSlot=-1;
function renderInv(){const g=$('invGrid');g.innerHTML='';for(let i=0;i<30;i++){const s=inv[i],e=document.createElement('div');e.className='slot'+(i===selSlot?' sel':'')+(i<6?' hb':'');e.innerHTML=s?'<b>'+IT[s.id].n+'</b><i>'+(IT[s.id].st>1?s.n:Math.round(s.d/(IT[s.id].dur||1)*100)+'%')+'</i>':'';e.onclick=()=>{if(selSlot<0){if(inv[i])selSlot=i}else{if(selSlot!==i){const a=inv[selSlot],b=inv[i];if(a&&b&&a.id===b.id&&IT[a.id].st>1){const m=Math.min(IT[a.id].st-b.n,a.n);b.n+=m;a.n-=m;if(!a.n)inv[selSlot]=null}else{inv[selSlot]=b;inv[i]=a}}selSlot=-1}renderInv();renderHot()};g.appendChild(e)}
 $('wornInfo').textContent='Надето: '+['head','body'].map(k=>worn[k]?IT[worn[k]].n:'—').join(' / ')+'   Выбрано: '+(selSlot>=0&&inv[selSlot]?IT[inv[selSlot].id].n:'—')}
function renderCraft(){const l=$('craftList');l.innerHTML='';const fl=nearForge();D.recipes.forEach(r=>{const it=IT[r.id],ok=canPay(r.c),k=learned.has(r.id),f=fl>=r.f,e=document.createElement('div');e.className='rec';e.innerHTML='<div><b>'+it.n+(r.n>1?' x'+r.n:'')+'</b><br><small>'+fmt(r.c)+' · '+r.t+' с'+(r.f?' · Стол '+r.f:'')+'</small></div>';
 const bt=document.createElement('button');if(!k){bt.textContent='Изучить '+r.bp+' шл.';bt.disabled=count('slag')<r.bp;bt.onclick=()=>{take('slag',r.bp);learned.add(r.id);renderCraft()}}else{bt.textContent=f?'Создать':'Нужен стол '+r.f;bt.disabled=!ok||!f;bt.onclick=()=>{pay(r.c);queue.push({r,t:r.t});renderCraft();renderQ()}}e.appendChild(bt);l.appendChild(e)});renderQ()}
function renderQ(){$('craftQ').textContent=queue.length?'Очередь: '+queue.map((q,i)=>IT[q.r.id].n+(i?'':' ('+Math.ceil(q.t)+'с)')).join(', '):'Очередь пуста'}
function openCore(){$('corePanel').style.display='block';renderCore()}
function renderCore(){const s=core.stock;$('coreInfo').innerHTML='Привилегия: радиус '+D.core.radius+' м. Запас апкипа: '+Object.keys(s).map(k=>IT[k].n+' '+Math.floor(s[k])).join(', ')+'<br>Без запаса детали гниют.';const l=$('coreBtns');l.innerHTML='';Object.keys(s).forEach(k=>{const b=document.createElement('button');b.textContent='Внести всё: '+IT[k].n+' ('+count(k)+')';b.onclick=()=>{s[k]+=count(k);take(k,count(k));renderCore();renderHot()};l.appendChild(b)});const rd=document.createElement('div');rd.textContent='Рейд-сложность базы: '+raidLevel();l.appendChild(rd)}
function raidLevel(){let sum=0;pieces.forEach(p=>{sum+=p.hp});return sum<800?'Light':sum<4000?'Medium':sum<12000?'Heavy':'Very Hard'}
function openShop(){$('shop').style.display='block';renderShop()}
function renderShop(){const l=$('shopList');l.innerHTML='<div>Шлак: '+count('slag')+'</div>';D.hub.shop.forEach(([id,n,c])=>{const b=document.createElement('button');b.textContent=IT[id].n+' x'+n+' — '+c+' шл.';b.disabled=count('slag')<c;b.onclick=()=>{take('slag',c);add(id,n);renderShop();renderHot()};l.appendChild(b)});
 const s=held(),rb=document.createElement('button');rb.textContent='Разобрать выбранный предмет (40 %)';rb.onclick=()=>{const s=held();if(!s)return;const r=D.recipes.find(x=>x.id===s.id);if(!r){log('Нет рецепта');return}Object.keys(r.c).forEach(k=>add(k,Math.floor(r.c[k]*.4)));add('slag',5);inv[P.sel]=null;renderShop();renderHot()};l.appendChild(rb)}
// ---------- сохранение ----------
function save(){if(!started)return;const o={v:D.saveVersion,inv,worn,learned:[...learned],P:{x:P.x,z:P.z,hp:P.hp,food:P.food,water:P.water,temp:P.temp,rad:P.rad},gameT,nextRaid,spawnPt,bedCd,stamp:Date.now(),
 pieces:[...pieces.values()].map(p=>({type:p.type,i:p.i,j:p.j,d:p.d,L:p.L,y:p.y,tier:p.tier,hp:p.hp,st:p.st,open:p.open})),deploys:deploys.map(d=>({k:d.k,x:d.x,y:d.y,z:d.z,lv:d.lv,hp:d.hp,stock:d.stock})),mags};localStorage.setItem('emb_save',JSON.stringify(o))}
function load(){let o;try{o=JSON.parse(localStorage.getItem('emb_save')||'null')}catch(e){}if(!o||o.v!==D.saveVersion)return false;
 o.inv.forEach((s,i)=>inv[i]=s);Object.assign(worn,o.worn);o.learned.forEach(k=>learned.add(k));Object.assign(P,o.P);P.y=gY(P.x,P.z)+1;gameT=o.gameT||0;nextRaid=o.nextRaid||D.bots.raidEvery;spawnPt=o.spawnPt;bedCd=o.bedCd||0;Object.assign(mags,o.mags||{});
 o.pieces.forEach(q=>{const p=mkPiece(q);setTier(p,q.tier);p.hp=q.hp;p.st=q.st;p.y=q.y;p.open=q.open;refreshDoor(p)});o.deploys.forEach(d=>{const x=Object.assign({t:0},d);mkDeploy(x);deploys.push(x);if(x.k==='core')core=x});
 const el=Math.min((Date.now()-o.stamp)/1000,D.time.offlineCap);if(el>5)decayTick(el);return true}
// ---------- ввод ----------
const keys={};let joy={x:0,y:0},joyId=null,lookId=null,lx=0,ly=0,jb={x:0,y:0};
function bind(id,dn,up){const e=$(id);if(!e)return;e.addEventListener('touchstart',ev=>{ev.preventDefault();ev.stopPropagation();dn()},{passive:false});e.addEventListener('touchend',ev=>{ev.preventDefault();up&&up()},{passive:false});e.addEventListener('mousedown',ev=>{ev.stopPropagation();dn()});e.addEventListener('mouseup',()=>up&&up())}
bind('bFire',()=>{firing=true;press();Gyro.hold=Gyro.hold},()=>{firing=false});
bind('bAds',()=>{ads=S.adsHold?true:!ads},()=>{if(S.adsHold)ads=false});
bind('bJump',()=>{keys.jump=true},()=>{keys.jump=false});bind('bCrouch',()=>{P.crouch=!P.crouch},null);
bind('bUse',interact,null);bind('bReload',reload,null);bind('bInv',()=>toggle('inv'),null);bind('bCraft',()=>{toggle('craft')},null);
bind('bGyro',()=>{Gyro.paused=true},()=>{Gyro.paused=false});bind('bGyroHold',()=>{Gyro.hold=true},()=>{Gyro.hold=false});
bind('bMenu',()=>pause(true),null);
document.querySelectorAll('#wheel button').forEach(b=>{b.onclick=()=>{bType=b.dataset.t;document.querySelectorAll('#wheel button').forEach(x=>x.classList.toggle('on',x===b))};b.ontouchstart=ev=>{ev.stopPropagation()}});
function toggle(id){const e=$(id);const open=e.style.display==='block';['inv','craft','corePanel','shop'].forEach(x=>$(x).style.display='none');if(!open){e.style.display='block';if(id==='inv')renderInv();if(id==='craft')renderCraft()}}
document.querySelectorAll('.close').forEach(b=>b.onclick=()=>{['inv','craft','corePanel','shop'].forEach(x=>$(x).style.display='none')});
const lookEl=$('hud');
lookEl.addEventListener('touchstart',ev=>{for(const t of ev.changedTouches){if(t.target.closest('.btn,#hotbar,#wheel,.panel'))continue;if(t.clientX<innerWidth*.38&&joyId===null){joyId=t.identifier;jb={x:t.clientX,y:t.clientY};$('joy').style.cssText='display:block;left:'+(jb.x-50)+'px;top:'+(jb.y-50)+'px';}else if(lookId===null&&t.clientX>=innerWidth*.38){lookId=t.identifier;lx=t.clientX;ly=t.clientY}}},{passive:false});
lookEl.addEventListener('touchmove',ev=>{for(const t of ev.changedTouches){if(t.identifier===joyId){let dx=(t.clientX-jb.x)/50,dy=(t.clientY-jb.y)/50;const l=Math.hypot(dx,dy);if(l>1){dx/=l;dy/=l}joy.x=dx;joy.y=dy;$('knob').style.transform='translate('+dx*35+'px,'+dy*35+'px)'}else if(t.identifier===lookId){const k=.0045*(ads?S.adsSens:S.sens);P.yaw-=(t.clientX-lx)*k;P.pitch-=(t.clientY-ly)*k*(S.invY?-1:1);lx=t.clientX;ly=t.clientY}}ev.preventDefault()},{passive:false});
const endT=ev=>{for(const t of ev.changedTouches){if(t.identifier===joyId){joyId=null;joy.x=joy.y=0;$('joy').style.display='none'}if(t.identifier===lookId)lookId=null}};lookEl.addEventListener('touchend',endT);lookEl.addEventListener('touchcancel',endT);
addEventListener('keydown',e=>{keys[e.code]=true;if(!started||paused)return;if(e.code==='KeyE')interact();if(e.code==='KeyR')reload();if(e.code==='KeyI')toggle('inv');if(e.code==='KeyC'&&!e.ctrlKey)toggle('craft');if(e.code==='ControlLeft')P.crouch=!P.crouch;if(e.code.startsWith('Digit')){const n=+e.code[5]-1;if(n>=0&&n<6){P.sel=n;renderHot()}}});addEventListener('keyup',e=>keys[e.code]=false);
cv.addEventListener('mousedown',e=>{if(!started||paused)return;if(document.pointerLockElement!==cv){cv.requestPointerLock&&cv.requestPointerLock();return}if(e.button===0){firing=true;press()}if(e.button===2)ads=true});addEventListener('mouseup',e=>{if(e.button===0)firing=false;if(e.button===2)ads=false});cv.addEventListener('contextmenu',e=>e.preventDefault());
addEventListener('mousemove',e=>{if(document.pointerLockElement===cv){const k=.0022*(ads?S.adsSens:S.sens);P.yaw-=e.movementX*k;P.pitch-=e.movementY*k}});
// ---------- настройки / гиро UI ----------
function bindSet(){const gc=Gyro.cfg,defs=[['sens','Чувств. камеры',.3,2,.05,S],['adsSens','Чувств. ADS',.2,2,.05,S],['fov','FOV',60,100,1,S],['assist','Помощь отдачи %',0,100,5,S],['sensHip','Гиро от бедра',.1,3,.05,gc],['sensAds','Гиро ADS',.1,3,.05,gc],['mx','Гиро множитель X',.2,3,.05,gc],['my','Гиро множитель Y',.2,3,.05,gc],['dead','Мёртвая зона',0,2,.05,gc],['smooth','Сглаживание',0,.9,.05,gc]];
 const box2=$('setBox');box2.innerHTML='';defs.forEach(([k,n,mn,mx,st,o])=>{const r=document.createElement('label');r.innerHTML=n+' <span></span><input type="range" min="'+mn+'" max="'+mx+'" step="'+st+'">';const i=r.querySelector('input'),sp=r.querySelector('span');i.value=o[k];sp.textContent=o[k];i.oninput=()=>{o[k]=+i.value;sp.textContent=i.value;if(k==='fov')cam.fov=+i.value,cam.updateProjectionMatrix();saveS();Gyro.save()};box2.appendChild(r)});
 const tg=[['invY','Инверсия Y (касание)',S],['fps','Показ FPS',S],['vib','Вибрация',S],['adsHold','ADS: удержание',S],['invX','Гиро: инверсия X',gc],['invY','Гиро: инверсия Y',gc],['precise','Гиро: точный режим (гравитация)',gc],['vehicle','Гиро в транспорте',gc]];
 tg.forEach(([k,n,o])=>{const r=document.createElement('label');r.innerHTML='<input type="checkbox"> '+n;const i=r.querySelector('input');i.checked=!!o[k];i.onchange=()=>{o[k]=i.checked;saveS();Gyro.save()};box2.appendChild(r)});
 const md=document.createElement('label');md.innerHTML='Режим гиро <select><option value="off">Выкл</option><option value="always">Всегда</option><option value="ads">Только ADS</option><option value="hold">Пока держу кнопку</option><option value="adsfire">ADS + стрельба</option></select>';const sel=md.querySelector('select');sel.value=gc.mode;sel.onchange=()=>{gc.mode=sel.value;Gyro.save()};box2.appendChild(md);
 const gq=$('gyroState');gq.textContent=Gyro.supported?'Датчик: найден':'Датчика нет (ПК?) — гиро отключено';if(!Gyro.supported)$('gyroBtns').style.display='none'}
$('gEnable').onclick=async()=>{const ok=await Gyro.requestPermission();if(ok){Gyro.enabled=true;Gyro.start();$('gyroState').textContent='Гиро включено'}else $('gyroState').textContent='Доступ запрещён. Включи «Движение и ориентация» в настройках браузера/приложения.'};
$('gCal').onclick=async()=>{Gyro.enabled=true;Gyro.start();const ok=await Gyro.calibrate(t=>$('gyroState').textContent=t);if(!ok)$('gyroState').textContent='Калибровка не удалась (нет доступа/датчика)'};
$('gCenter').onclick=()=>{$('gyroState').textContent='Не двигай телефон 1 сек…';Gyro.center();setTimeout(()=>$('gyroState').textContent='Центр обновлён',1100)};
$('gReset').onclick=()=>{Gyro.reset();bindSet()};
$('gTest').onclick=()=>{Gyro.enabled=true;Gyro.start();const t=$('gTestBox');t.style.display='block';let x=0,y=0;Gyro.sink=(yw,pt)=>{x=clamp(x+yw*.02,-1,1);y=clamp(y-pt*.02,-1,1);$('tDot').style.transform='translate('+x*80+'px,'+y*50+'px)';$('tNum').textContent='yaw '+yw.toFixed(1)+'°/с  pitch '+pt.toFixed(1)+'°/с  угол экрана '+Gyro.angle()};$('tClose').onclick=()=>{t.style.display='none';Gyro.sink=null}};
// ---------- меню ----------
function pause(p){paused=p;$('lobby').style.display=p?'flex':'none';$('hud').style.display=p?'none':'block';if(p){Gyro.stop();save();firing=false;if(document.exitPointerLock)document.exitPointerLock();$('btnPlay').textContent=started?'ПРОДОЛЖИТЬ':'ИГРАТЬ'}else{if(Gyro.enabled)Gyro.start();if(document.documentElement.requestFullscreen&&!document.fullscreenElement)document.documentElement.requestFullscreen().catch(()=>{});if(screen.orientation&&screen.orientation.lock)screen.orientation.lock('landscape').catch(()=>{});if(navigator.wakeLock)navigator.wakeLock.request('screen').catch(()=>{})}}
$('btnPlay').onclick=()=>{if(!started){started=true;if(!load()){respawn(false)}renderHot();bindSet()}pause(false)};
$('btnSet').onclick=()=>{$('settings').style.display='block'};$('setClose').onclick=()=>{$('settings').style.display='none'};
$('btnReset').onclick=()=>{if(confirm('Стереть сезон? Настройки сохранятся.')){localStorage.removeItem('emb_save');location.reload()}};
$('resRand').onclick=()=>respawn(false);$('resBed').onclick=()=>{respawn(true);bedCd=gameT+300};
bindSet();if(Gyro.supported&&typeof DeviceMotionEvent.requestPermission!=='function'&&Gyro.cfg.mode!=='off')Gyro.enabled=true;
function orient(){$('rot').style.display=innerHeight>innerWidth?'flex':'none'}addEventListener('resize',orient);orient();
// ---------- главный цикл ----------
const skyD=new T.Color(0x87b8e8),skyN=new T.Color(0x05070f),skyS=new T.Color(0xe08855),tmp=new T.Color();scene.background=new T.Color(skyD);scene.fog=new T.Fog(0x87b8e8,60,260);
let last=performance.now(),acc=0,fpsT=0,fpsN=0,bobT=0;
function step(dt){gameT+=dt;
 if(!P.dead){let fx=0,fz=0;if(keys.KeyW)fz-=1;if(keys.KeyS)fz+=1;if(keys.KeyA)fx-=1;if(keys.KeyD)fx+=1;fx+=joy.x;fz+=joy.y;const l=Math.hypot(fx,fz);if(l>1){fx/=l;fz/=l}moving=l>.1;
  const run=(joy.y<-.95||keys.ShiftLeft)&&!P.crouch&&!P.wounded;let sp=P.wounded?1.2:P.swim?2.5:P.crouch?2.2:run?6.5:4.5;if(ads)sp*=.6;
  const sy=Math.sin(P.yaw),cy=Math.cos(P.yaw);P.x+=(fx*cy+fz*sy)*sp*dt;P.z+=(-fx*sy+fz*cy)*sp*dt;
  const lim=SZ/2*1.05;const rr=Math.hypot(P.x,P.z);if(rr>lim){P.x*=lim/rr;P.z*=lim/rr}
  collide();const gy=gY(P.x,P.z);P.swim=H(P.x,P.z)<-.2&&P.y<.3;
  if(P.swim){P.y=lerp(P.y,-.3,dt*4);P.vy=0}else{P.vy-=22*dt;P.y+=P.vy*dt;if(P.y<=gy){if(P.vy<-12)hurt((-P.vy-12)*5,'fall');P.y=gy;P.vy=0;P.ground=true}else P.ground=false;if(keys.jump||keys.Space){if(P.ground&&!P.wounded){P.vy=7;P.ground=false}}}
  if(moving&&P.ground)bobT+=dt*sp*1.8}
 survTick(dt);fireTick(dt);
 const s=held(),it=s&&IT[s.id];if(it&&it.t==='gun'){const m=mags[s.id];if(m&&m.rl>0){m.rl-=dt;if(m.rl<=0){take(it.ammo,m.pend);m.n+=m.pend;renderHot()}}}
 recoilK=Math.max(0,recoilK-dt*8);
 updAnimals(dt);updBots(dt);updBullets(dt);
 barrels.forEach(b=>{if(b.cd>0){b.cd-=dt;if(b.cd<=0)b.m.visible=true}});res.forEach(n=>{if(n.rt>0){n.rt-=dt;if(n.rt<=0){n.left=n.max;n.inst.forEach(m=>{place(m,n.i,n.x,n.y+(n.k==='tree'?0:.5),n.z,n.s,0);m.instanceMatrix.needsUpdate=true})}}});
 deploys.forEach(d=>{if(d.k==='charge'&&d.fuse>0){d.fuse-=dt;if(d.fuse<=0){explode(d.x,d.y+.5,d.z,D.explosive.charge.dmg,4);scene.remove(d.m);deploys.splice(deploys.indexOf(d),1)}}});
 if(queue.length){const q=queue[0];q.t-=dt;if(q.t<=0){add(q.r.id,q.r.n);queue.shift();log('Создано: '+IT[q.r.id].n);renderHot();if($('craft').style.display==='block')renderCraft()}if($('craft').style.display==='block')renderQ()}
 decT+=dt;if(decT>=10){decayTick(decT);decT=0}saveT+=dt;if(saveT>20){save();saveT=0}
 // рейд-ночь
 if(core){nextRaid-=dt;if(nextRaid<D.bots.warn&&!raidWarn){raidWarn=true;$('banner').textContent='РЕЙД-НОЧЬ через 2 минуты! Укрепи базу.';$('banner').style.display='block';setTimeout(()=>$('banner').style.display='none',6000)}
  if(nextRaid<=0){nextRaid=D.bots.raidEvery;raidWarn=false;for(let i=0;i<D.bots.raiders;i++){const a=rnd(0,6.28);let x=core.x+Math.cos(a)*60,z=core.z+Math.sin(a)*60;if(H(x,z)<1){x=core.x+Math.cos(a+3)*45;z=core.z+Math.sin(a+3)*45}spawnRaider(x,z,['Rex','Mora','Kiro','Vlad'][i%4]+'_'+Math.floor(rnd(10,99)))}log('[BOT] Рейдеры идут на базу!')}}}
function frame(now){requestAnimationFrame(frame);const raw=Math.min((now-last)/1000,.1);last=now;if(!started||paused){R.render(scene,cam);return}
 acc+=raw;while(acc>=1/60){step(1/60);acc-=1/60}
 // гиро + камера
 const zoom=(it=>it&&it.zoom)(held()&&IT[held().id])||1.25;const g=Gyro.consume(ads,zoom,firing,false);P.yaw-=g.yaw;P.pitch+=g.pitch;P.pitch=clamp(P.pitch,-1.5,1.5);
 swingT=Math.max(0,swingT-raw);const bob=Math.sin(bobT)*.04;
 cam.position.set(P.x,P.y+(P.crouch?1.1:1.6)+bob-(P.wounded?.9:0),P.z);cam.rotation.set(P.pitch,P.yaw,0,'YXZ');cam.updateMatrixWorld();
 const tf=S.fov/(ads?zoom:1);cam.fov=lerp(cam.fov,tf,raw*12);cam.updateProjectionMatrix();
 // время суток
 const ph=dayPhase(),sf=ph.day?Math.sin(ph.f*Math.PI):0,dusk=ph.day?Math.pow(1-Math.abs(ph.f-.5)*2,.3):0;tmp.copy(skyN).lerp(skyD,Math.min(1,sf*1.8));if(ph.day&&(ph.f<.12||ph.f>.88))tmp.lerp(skyS,.5);scene.background.copy(tmp);scene.fog.color.copy(tmp);scene.fog.far=ph.day?260:90;
 hemi.intensity=.18+sf*.8;sun.intensity=sf*.9;sun.position.set(Math.cos(ph.f*Math.PI)*100,Math.sin(ph.f*Math.PI)*100+10,50);
 const hs=held(),hit=hs&&IT[hs.id];torchL.intensity=hit&&hit.light?1.1+Math.random()*.2:(ph.day?0:.15);
 const fire=deploys.find(d=>d.k==='campfire'&&Math.hypot(d.x-P.x,d.z-P.z)<40);if(fire){fireL.position.set(fire.x,fire.y+1,fire.z);fireL.intensity=1.2+Math.random()*.4}else fireL.intensity=0;
 water.position.y=Math.sin(now/900)*.12;water.position.x=P.x;water.position.z=P.z;
 updateGhost();
 // хотспот
 let hn=null,hd=9;if(hit&&hit.t==='tool')res.forEach(n=>{if(n.k!=='tree'&&n.left>0&&facing(n.x,n.z,8,.6)){const dd=Math.hypot(n.x-P.x,n.z-P.z);if(dd<hd){hd=dd;hn=n}}});hotspot.visible=!!hn;if(hn)hotspot.position.set(hn.x+Math.cos(hn.hs)*hn.r*.8,hn.y+.9*hn.s,hn.z+Math.sin(hn.hs)*hn.r*.8);
 hud(raw);R.render(scene,cam)}
const bars={hp:$('bHp'),food:$('bFood'),water:$('bWater'),temp:$('bTemp'),rad:$('bRad')};
function hud(dt){bars.hp.style.width=clamp(P.hp,0,100)+'%';bars.food.style.width=P.food+'%';bars.water.style.width=P.water+'%';bars.temp.style.width=clamp((P.temp+10)*2.5,0,100)+'%';bars.rad.style.width=clamp(P.rad/5,0,100)+'%';
 const dirs=['С','СВ','В','ЮВ','Ю','ЮЗ','З','СЗ'];const deg=((-P.yaw*57.2958)%360+360)%360;$('compass').textContent=dirs[Math.round(deg/45)%8]+' '+Math.round(deg)+'°';
 const inCore=core&&Math.hypot(P.x-core.x,P.z-core.z)<D.core.radius;$('priv').style.display=inCore?'block':'none';$('safe').style.display=hubD(P.x,P.z)<D.hub.r?'block':'none';
 const ds=dayPhase();$('clock').textContent=(ds.day?'День ':'Ночь ')+Math.floor(ds.f*100)+'%';$('status').textContent=(P.bleed>0?'Кровь ':'')+(P.wounded>0?'РАНЕН ':'')+(P.rad>25?'Радиация ':'')+(P.temp<D.surv.coldBelow?'Холод ':'')+(P.swim?'Плывёшь ':'');
 const s=held();let inf='';if(s&&IT[s.id].t==='hammer'){const r=rayPieces(cam.position,aim(),5);if(r)inf=D.tiers[r.p.tier].n+' · HP '+Math.round(r.p.hp)+' · стабильность '+Math.round(r.p.st||0)+'%'}else if(gInfo&&gInfo.b&&gInfo.b.st!=null&&gInfo.b.type!=='found')inf='Стабильность '+Math.round(gInfo.b.st)+'%';$('info').textContent=inf;
 $('bAds').style.display=s&&['gun','bow'].includes(IT[s.id].t)?'flex':'none';$('bReload').style.display=s&&IT[s.id].t==='gun'?'flex':'none';
 if(S.fps){fpsT+=dt;fpsN++;if(fpsT>.5){$('fps').textContent=Math.round(fpsN/fpsT)+' FPS';fpsT=fpsN=0}}else $('fps').textContent=''}
document.addEventListener('visibilitychange',()=>{if(document.hidden&&started)pause(true)});
addEventListener('beforeunload',save);
requestAnimationFrame(frame);
})();
