# EMBERHOLD: Остров Пепла

## Как получить APK (без компьютера)
1. На github.com создай репозиторий (New repository, Public/Private — любой).
2. Загрузи файлы проекта: Add file → Upload files (www/, package.json, capacitor.config.json, .gitignore).
3. Файл `.github/workflows/build-apk.yml` создай вручную: Add file → Create new file, в имени файла напечатай
   `.github/workflows/build-apk.yml` (слэши создадут папки), вставь содержимое, Commit.
4. Вкладка Actions → Build APK → ждёшь зелёную галочку (5–10 мин). Если не запустилось: Run workflow.
5. Внутри запуска внизу Artifacts → app-debug.apk (скачивается в zip → распакуй → установи, разреши «Неизвестные источники»).

## Игра
- Тач: левая часть экрана — стик, правая — камера. Кнопки справа. Гиро: Настройки → Включить гироскоп → Калибровка.
- iOS: гироскопу нужен тап «Включить гироскоп». Android: включается сам (режим «Только ADS» по умолчанию).
- ПК для проверки: WASD, мышь, E, R, I, C, 1–6.
- Все числа баланса: `www/data.js`.
